using System;
class DisplayDogFacts
{
   static void Main()
   {
      Console.WriteLine("Dogs were first domesticated at least 17,000 years ago");
   }
}