using System;
class DisplayDogFacts
{
   static void Main()
   {
      Console.WriteLin("Dogs were first domesticated at least 17,000 years ago");
   }
}